


--
-- Database: `building_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_block`
--

CREATE TABLE `add_block` (
  `id` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `blockname` text NOT NULL,
  `rooms` int(11) NOT NULL,
  `parking` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_block`
--


-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `ID` int(11) NOT NULL,
  `type` text NOT NULL,
  `info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `c_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `block` varchar(25) DEFAULT NULL,
  `doorno` varchar(25) NOT NULL,
  `issue_type` text NOT NULL,
  `repeated` text NOT NULL,
  `replacement` text NOT NULL,
  `mobno` bigint(20) DEFAULT NULL,
  `issue` text NOT NULL,
 `dob` date NOT NULL,
  `status` text NOT NULL
) 


--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `ID` int(11) NOT NULL,
  `type` text NOT NULL,
  `mobno` bigint(20) NOT NULL
)

--


-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `ID` int(11) NOT NULL,
  `type` text NOT NULL,
  `date` date NOT NULL,
  `time` varchar(25) NOT NULL,
  `no` int(11) NOT NULL
) 

--

-- --------------------------------------------------------

--
-- Table structure for table `issue_details`
--

CREATE TABLE `issue_details` (
  `id` int(255) NOT NULL,
  `worker_name` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `block` varchar(255) NOT NULL,
  `door` varchar(255) NOT NULL,
  `issue` varchar(255) NOT NULL,
  `repeated` varchar(255) NOT NULL,
  `replacement` varchar(255) NOT NULL,
  `mob_num` varchar(255) NOT NULL,
  `issues` varchar(255) NOT NULL,
  `dateofreporting` date NOT NULL,
  `worker_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending'
) 
--


--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` text NOT NULL,
  `assignblock` varchar(25) NOT NULL,
  `mobno` bigint(20) NOT NULL,
  `dob` date NOT NULL,
  `nationality` text NOT NULL
)

--
-- Table structure for table `parking`
--

CREATE TABLE `parking` (
  `ID` int(25) NOT NULL,
  `name` text NOT NULL,
  `allotment` varchar(25) NOT NULL,
  `mobno` bigint(20) NOT NULL
) 

--


-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `status` text NOT NULL,
  `comment` text NOT NULL,
  `rate` int(11) NOT NULL,
  `date` date NOT NULL
) 
--


-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE `security` (
  `ID` varchar(255) NOT NULL,
  `camera` varchar(255) NOT NULL,
  `carbon` varchar(255) NOT NULL,
  `alarm` varchar(255) NOT NULL,
  `blockname` varchar(255) NOT NULL
) 
--
-- Dumping data for table `security`
--


--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `issue_details`
--
ALTER TABLE `issue_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `issue_details`
--
ALTER TABLE `issue_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;


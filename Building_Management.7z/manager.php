<?php
$conn = mysqli_connect("localhost", "root", "", "building_management");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to retrieve data from the 'complaints' table
$sql = "SELECT * FROM complaints WHERE status='pending'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search and Buttons Example</title>
    
    <style>
        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav {
            background-color: #333;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 50px;
        }

        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        .search-bar {
            width: 100%;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .search-icon {
            font-size: 20px;
            margin-right: 10px;
            color: #333;
        }

        .search-input {
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            width: 200px;
            outline: none;
        }

        .search-input::placeholder {
            color: #999;
        }

        nav li {
            margin: 0 10px;
        }

        nav a {
            text-decoration: none;
            color: black;
        }
          
        .employee-table {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .highlight {
            background-color: #f0f0f0;
            font-weight: bold;
        }

        .employee-table h3 {
            margin-top: 0;
        }

        .employee-table table {
            width: 100%;
            border-collapse: collapse;
        }

        .employee-table th, .employee-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
        }

        .employee-table th {
            background-color: #f2f2f2;
        }
        
    </style>
  
</head>
<body>

    <header>
        <center>
            <h1>Smart Building</h1>
        </center>
    </header>
    <nav>
        <ul>
            <li><a href="viewstaff.php">Assigned Work</a></li>
            <li><a href="jobhistory.php">Status</a></li>
            <li><a href="managerprofile.php">Profile</a></li>
            <li><a href="login.php">Logout</a></li>
        </ul>
    </nav>

    <main>
        <div class="search-bar">
            <span class="search-icon">&#128269;</span>
            <input type="text" id="search-input" class="search-input" placeholder="Search..." oninput="searchTable()">
        </div>
        <div class="employee-table">
            <h3>Issues  <a href="issuedetails.php" class="choose-button">Next</a></h3>
            <table>
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Name</th>
                        <th>Block</th>
                        <th>Door.no</th>
                        <th>Issue Type</th>
                        <th>Mob.No</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . (isset($row['c_id']) ? $row['c_id'] : '') . "</td>";
                        echo "<td>" . (isset($row['name']) ? $row['name'] : '') . "</td>";
                        echo "<td>" . (isset($row['block']) ? $row['block'] : '') . "</td>";
                        echo "<td>" . (isset($row['doorno']) ? $row['doorno'] : '') . "</td>";
                        echo "<td>" . (isset($row['issue_type']) ? $row['issue_type'] : '') . "</td>";
                        echo "<td>" . (isset($row['mobno']) ? $row['mobno'] : '') . "</td>";
                        echo "<td>" . (isset($row['status']) ? $row['status'] : '') . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <!-- Your footer content goes here -->
    </footer>

    <script>
        function searchTable() {
            var input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("search-input");
            filter = input.value.toUpperCase();
            table = document.querySelector(".employee-table table");
            tr = table.getElementsByTagName("tr");

            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[1];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }
    </script>

</body>
</html>

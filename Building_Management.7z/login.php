<?php
$conn = mysqli_connect("localhost", "root", "", "building_management");
session_start();
if(isset($_POST['submit']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $query = "select * from login where username='$username' and password='$password' ";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);
    $data = $conn->query($query);
    $user = $data->fetch_assoc();
    $_SESSION['id'] = $user['id']; // Corrected variable name
    $_SESSION['name'] = $user['name'];
    
    if ($row['role'] == "admin") { 
        header('location: dashboard.php');
    }
    elseif ($row['role'] == "manager") {
        header('location: manager.php');
    }
    elseif ($row['role'] == "user") {
        header('location: user.php');
    }
    elseif ($row['role'] == "staff") {
        header('location: staff.php');
    }
    else {
        // Invalid username or password
        header("location: login.php");
        echo "Wrong password and username";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Smart Building</title>
    <style>
        #submit {
            border: 5px solid;
            height: 50%;
            width: 18%;
            font-size: 20px;
            background-color: rgba(60, 80, 150, 1);
            color: white;
        }

        #ground {
            padding-bottom: 100px;
        }
    </style>
</head>
<body style="background-color: white;">
    <p id="ground">
        <center>
        
            <img src="smartbuild.jpg"  width="350" height="250">
            <h2>Smart Building</h2>
            <form action="" method="post">
                <div id="page">
                    Username: <input type="text" name="username"><br><br>
                    Password: <input type="password" name="password"><br><br>
                    <input type="submit" name="submit" value="Submit">
                </div>
            </form>
        </center>
    </p>
</body>
</html>

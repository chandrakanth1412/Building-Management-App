-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 27, 2023 at 03:55 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `building_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_block`
--

CREATE TABLE `add_block` (
  `id` int(11) NOT NULL,
  `floor` int(11) NOT NULL,
  `blockname` text NOT NULL,
  `rooms` int(11) NOT NULL,
  `parking` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_block`
--

INSERT INTO `add_block` (`id`, `floor`, `blockname`, `rooms`, `parking`) VALUES
(1, 6, 'SSE', 40, 'yes'),
(2, 12, 'AHS', 30, 'yes'),
(3, 3, 'SAIL', 25, 'yes'),
(4, 8, 'Scad', 9, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `ID` int(11) NOT NULL,
  `type` text NOT NULL,
  `info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`ID`, `type`, `info`) VALUES
(1, 'VOLUNTER NEEDED', 'Needed volunteer for the Diwali festival event  For further info contact secretary'),
(2, 'TOLET', 'A - Block, House number A102 2BHK flat is available for rent '),
(3, 'Birthday', '11.00Am'),
(6, 'Birthday', '11.00Am');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `c_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `block` varchar(25) DEFAULT NULL,
  `doorno` varchar(25) NOT NULL,
  `issue_type` text NOT NULL,
  `repeated` text NOT NULL,
  `replacement` text NOT NULL,
  `mobno` bigint(20) DEFAULT NULL,
  `issue` text NOT NULL,
  `dob` date NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`c_id`, `name`, `block`, `doorno`, `issue_type`, `repeated`, `replacement`, `mobno`, `issue`, `dob`, `status`) VALUES
(0, 'Nandini', 'SSE', 'A-101', 'plumbing', 'Yes', '', 9652060575, 'plekage', '2023-12-08', 'completed'),
(2, 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', 'no', 9652060575, 'alteration for main door', '2023-11-10', 'pending'),
(3, 'keerthi', 'SCAD', 'C-101', 'Electrical', 'no', 'no', 9985260873, 'Fire alarm ', '2023-11-14', 'completed'),
(4, 'Nandini', 'AHS', 'A-101', 'gardening', 'no', 'no', 9652060575, 'water lekage', '2023-11-16', 'pending'),
(5, 'Keerthi', 'SAIL', 'C-101', 'Gardening', 'Yes', '', 9985260873, 'cleaning all the palces', '2023-12-02', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `ID` int(11) NOT NULL,
  `type` text NOT NULL,
  `mobno` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`ID`, `type`, `mobno`) VALUES
(1, 'Shashi-Admin', 8688864002),
(2, 'POLICE', 100),
(3, 'Birthday', 11),
(6, 'Birthday', 11);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `ID` int(11) NOT NULL,
  `type` text NOT NULL,
  `date` date NOT NULL,
  `time` varchar(25) NOT NULL,
  `no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`ID`, `type`, `date`, `time`, `no`) VALUES
(1, 'Party', '2023-11-15', '11.00AM', 50),
(2, 'Meeting', '2023-11-17', '11.00AM', 5),
(3, 'Birthday', '0000-00-00', '11.00Am', 50),
(4, 'Manger', '1212-12-12', 'B block`', 2147483647),
(5, 'h', '0000-00-00', 'h', 0);

-- --------------------------------------------------------

--
-- Table structure for table `issue_details`
--

CREATE TABLE `issue_details` (
  `id` int(255) NOT NULL,
  `worker_name` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `block` varchar(255) NOT NULL,
  `door` varchar(255) NOT NULL,
  `issue` varchar(255) NOT NULL,
  `repeated` varchar(255) NOT NULL,
  `replacement` varchar(255) NOT NULL,
  `mob_num` varchar(255) NOT NULL,
  `issues` varchar(255) NOT NULL,
  `dateofreporting` date NOT NULL,
  `worker_id` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issue_details`
--

INSERT INTO `issue_details` (`id`, `worker_name`, `user_name`, `block`, `door`, `issue`, `repeated`, `replacement`, `mob_num`, `issues`, `dateofreporting`, `worker_id`, `user_id`, `status`) VALUES
(11, 'Divya', 'Nandini', ' A block', 'A-101', 'carpenting', 'no', 'no', '9652060575', 'alteration for main door', '2023-11-10', '3', '2', 'completed'),
(16, 'Divya', 'Nandini', 'A-Block', 'A-101', 'plumbing', 'Yes', '', '9652060575', 'plekage', '2023-12-08', '3', '2', 'completed'),
(17, 'divya', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', 'no', '9652060575', 'alteration for main door', '2023-11-10', '3', '2', 'completed'),
(22, 'divya', 'Nandini', 'A-Block\n', 'A-101', 'painting', 'no', '', '9652060575', 'wall painting', '2023-01-08', '', '', 'completed'),
(29, 'moni', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', '', '9652060575', 'alteration for main door', '2023-11-10', '', '', 'completed'),
(36, 'Geetha', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', '', '9652060575', 'alteration for main door', '2023-11-10', '', '', 'completed'),
(37, 'moni', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', '', '9652060575', 'alteration for main door', '2023-11-10', '', '', 'completed'),
(38, 'Geetha', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', '', '9652060575', 'alteration for main door', '2023-11-10', '', '', 'completed'),
(39, 'Geetha', 'Nandini', 'AHS', 'A-101', 'gardening', 'no', '', '9652060575', 'water lekage', '2023-11-16', '', '', 'completed'),
(40, 'moni', 'Nandini', 'AHS', 'A-101', 'gardening', 'no', '', '9652060575', 'water lekage', '2023-11-16', '', '', 'pending'),
(41, 'moni', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', '', '9652060575', 'alteration for main door', '2023-11-10', '', '', 'completed'),
(42, 'divya', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', 'no', '9652060575', 'alteration for main door', '2023-11-10', '3', '2', 'pending'),
(43, 'Geetha', 'Nandini', 'SAIL', 'A-101', 'carpenting', 'no', '', '9652060575', 'alteration for main door', '2023-11-10', '', '', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` text NOT NULL,
  `assignblock` varchar(25) NOT NULL,
  `mobno` bigint(20) NOT NULL,
  `dob` date NOT NULL,
  `nationality` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `name`, `username`, `password`, `role`, `assignblock`, `mobno`, `dob`, `nationality`) VALUES
(1, 'shashi', 'd12', '123', 'admin', 'A block', 8688861400, '2023-12-06', ''),
(2, 'moni', 'm12', '123', 'manager', 'C block', 9676224970, '2023-12-07', ''),
(3, 'divya', 's12', '123', 'staff', 'C block', 9985260873, '2023-12-13', ''),
(4, 'Nandini', 'n12', '123', 'user', 'A-101', 9652060575, '2023-12-08', ''),
(5, 'Geetha', 'm13', '123', 'manager', 'C Block', 7896534247, '2023-12-09', 'Indian'),
(8, 'mini', 'm14', '123', 'staff', 'c block', 7878787878, '1212-12-12', 'Indian');

-- --------------------------------------------------------

--
-- Table structure for table `parking`
--

CREATE TABLE `parking` (
  `ID` int(25) NOT NULL,
  `name` text NOT NULL,
  `allotment` varchar(25) NOT NULL,
  `mobno` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parking`
--

INSERT INTO `parking` (`ID`, `name`, `allotment`, `mobno`) VALUES
(1, 'Keerthi', 'SA01', 9985260873),
(2, 'Nandini', 'SA02', 9652060575),
(4, 'Geetha', 'SA03', 9652060575);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `status` text NOT NULL,
  `comment` text NOT NULL,
  `rate` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `name`, `status`, `comment`, `rate`, `date`) VALUES
(1, 'keerthi', 'completed', 'good', 4, '2023-10-04'),
(2, 'harsha', 'pending', 'need maintanence ', 1, '2023-10-02'),
(3, 'keerthi', 'completed', 'good', 4, '0000-00-00'),
(0, 'karthik', 'completed', 'good', 5, '0000-00-00'),
(21, 'karthik', 'completed', 'good', 5, '0000-00-00'),
(22, 'karthik', 'completed', 'good', 5, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE `security` (
  `ID` varchar(255) NOT NULL,
  `camera` varchar(255) NOT NULL,
  `carbon` varchar(255) NOT NULL,
  `alarm` varchar(255) NOT NULL,
  `blockname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `security`
--

INSERT INTO `security` (`ID`, `camera`, `carbon`, `alarm`, `blockname`) VALUES
('1', '10', '5', '5', 'SSE'),
('2', '15', '10', '5', 'AHS');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `issue_details`
--
ALTER TABLE `issue_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `issue_details`
--
ALTER TABLE `issue_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
